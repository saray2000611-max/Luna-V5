# یادداشت ساخت

- نسخهٔ پلاگین Android Gradle Plugin: 8.13.0
- نسخهٔ پیشنهادی Gradle: 8.13
- نسخهٔ Java هدف: 17
- مدل سه‌بعدی: GLB 2.0؛ انیمیشن‌های Turn/Sit/Stand در ساختار مدل شناسایی شده‌اند.
- وابستگی PDF: PDFBox Android
- وابستگی WebView Asset Loader: AndroidX WebKit
- ZIP از نظر ساختاری بررسی می‌شود، اما build واقعی Gradle در محیط بسته‌سازی اجرا نشده است.
- کتابخانهٔ `model-viewer.min.js` در ZIP اولیه وجود ندارد؛ در Termux با `bash DOWNLOAD_OFFLINE_VIEWER_FA.sh` اضافه می‌شود.
- مدل زبانی مولد و وزن‌های آن در این نسخه وجود ندارد.

- نسخهٔ تغییریافته: جست‌وجوی وب best-effort (Google HTML سپس DuckDuckGo)، کش آخرین نتیجه، و یادداشت‌های مقدماتی باستان‌شناسی آفلاین اضافه شده‌اند.
- خطای نحوی توالی `\\n` در وابستگی‌های `app/build.gradle` اصلاح شد.
- APK در این محیط ساخته/آزمایش نشده است.

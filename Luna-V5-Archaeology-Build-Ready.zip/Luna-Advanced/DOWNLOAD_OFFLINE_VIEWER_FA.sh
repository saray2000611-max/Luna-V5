#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
ASSETS="$ROOT/app/src/main/assets"
for file in luna-model-viewer.min.js Luna_Realistic_Avatar.glb Luna_3D_Voice.glb; do
  if [ ! -s "$ASSETS/$file" ]; then
    echo "فایل لازم پیدا نشد: $ASSETS/$file" >&2
    exit 1
  fi
done
echo "نمایشگر آفلاین و هر دو مدل سه‌بعدی داخل بسته موجودند؛ دانلود اینترنتی لازم نیست."
echo "این نمایشگر یک پیاده‌سازی سبک مخصوص لونا است، نه کتابخانهٔ رسمی Google model-viewer."

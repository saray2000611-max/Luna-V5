package com.luna.ai.web

import android.text.Html
import android.os.Build
import java.io.BufferedInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.Charset
import java.util.regex.Pattern

data class WebResult(val text: String, val sources: List<String>)

class WebResearch {
    /**
     * Lightweight, keyless web research: try Google HTML first, then DuckDuckGo.
     * Network access is required. Search engines can change markup or block automated requests;
     * failures are returned honestly rather than fabricated.
     */
    fun search(query: String, archaeologyMode: Boolean = false): WebResult {
        val q = query.trim()
        require(q.isNotBlank()) { "عبارت جست‌وجو خالی است." }
        val effectiveQuery = if (archaeologyMode) "$q باستان شناسی" else q
        var results: List<Triple<String, String, String>> = emptyList()
        var googleFailure: Exception? = null
        try {
            val googleUrl = "https://www.google.com/search?q=" +
                URLEncoder.encode(effectiveQuery, "UTF-8") + "&num=5"
            results = parseGoogleResults(fetch(googleUrl)).take(5)
        } catch (e: Exception) {
            googleFailure = e
        }
        var engineName = "گوگل"
        if (results.isEmpty()) {
            engineName = "DuckDuckGo (جایگزین)"
            val ddgUrl = "https://html.duckduckgo.com/html/?q=" +
                URLEncoder.encode(effectiveQuery, "UTF-8")
            results = try { parseResults(fetch(ddgUrl)).take(5) } catch (e: Exception) {
                if (googleFailure != null) throw IllegalStateException("گوگل و موتور جایگزین در دسترس نیستند؛ اتصال اینترنت را بررسی کن.")
                throw e
            }
        }
        if (results.isEmpty()) {
            return WebResult(
                "صفحهٔ جست‌وجو دریافت شد، اما نتیجه‌ای قابل استخراج پیدا نکردم. ممکن است موتور جست‌وجو ساختار صفحه را تغییر داده یا دسترسی خودکار را محدود کرده باشد. عبارت را کوتاه‌تر کن یا بعداً دوباره تلاش کن.",
                emptyList()
            )
        }

        val collected = mutableListOf<String>()
        val sources = mutableListOf<String>()
        for ((title, link, snippet) in results.take(4)) {
            if (!link.startsWith("https://") && !link.startsWith("http://")) continue
            val pageText = try { extractPageText(fetch(link)) } catch (_: Exception) { "" }
            val body = pageText.take(1300)
            val section = buildString {
                append("• ").append(title).append('\n')
                if (snippet.isNotBlank()) append("خلاصهٔ نتیجه: ").append(snippet).append('\n')
                if (body.isNotBlank()) append("متن استخراج‌شده از صفحه: ").append(body)
                else append("متن کامل صفحه دریافت نشد؛ این بخش بر اساس خلاصهٔ نتیجه است.")
            }
            collected += section
            sources += "$title — $link"
        }
        if (collected.isEmpty()) {
            return WebResult("نتایج پیدا شدند، اما نتوانستم محتوای قابل‌استفاده‌ای از صفحات استخراج کنم.", sources)
        }

        val heading = (if (archaeologyMode) "پژوهش وب در زمینهٔ باستان‌شناسی" else "نتیجهٔ جست‌وجوی وب") +
            " (موتور: $engineName)"
        val caution = if (archaeologyMode) {
            "\n\nیادآوری باستان‌شناسی: این جمع‌بندی اولیه است؛ برای تاریخ‌گذاری، اصالت یا تفسیر یک اثر باید به گزارش کاوش، مقالهٔ علمی و نظر متخصص استناد کرد."
        } else {
            "\n\nتوجه: این جمع‌بندی خودکار از نتایج و متن صفحات است؛ برای تصمیم مهم، منبع اصلی را بازبینی کن."
        }
        return WebResult("$heading برای «$q»:\n\n${collected.joinToString("\n\n")}$caution\n\nمنابع:\n${sources.joinToString("\n")}", sources)
    }

    private fun fetch(urlText: String): String {
        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.connectTimeout = 12000
        connection.readTimeout = 15000
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
        connection.setRequestProperty("Accept-Language", "fa-IR,fa;q=0.9,en;q=0.8")
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("سرور وب پاسخ $code برگرداند.")
            return BufferedInputStream(connection.inputStream).use { input ->
                val bytes = input.readBytes()
                val contentType = connection.contentType.orEmpty()
                val charsetName = Regex("(?i)charset=([^; ]+)").find(contentType)?.groupValues?.get(1)?.trim('"')
                val charset = try { if (charsetName != null) Charset.forName(charsetName) else Charsets.UTF_8 } catch (_: Exception) { Charsets.UTF_8 }
                String(bytes, charset)
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun parseGoogleResults(html: String): List<Triple<String, String, String>> {
        val out = mutableListOf<Triple<String, String, String>>()
        val anchors = Pattern.compile("""(?is)<a\b[^>]*href=["']([^"']+)["'][^>]*>(.*?)</a>""").matcher(html)
        while (anchors.find() && out.size < 8) {
            val rawHref = decodeEntities(anchors.group(1))
            val inner = anchors.group(2)
            if (!Regex("""(?is)<h3\b""").containsMatchIn(inner)) continue
            val title = htmlToText(Regex("""(?is)<h3\b[^>]*>(.*?)</h3>""").find(inner)?.groupValues?.get(1).orEmpty()).take(180)
            val link = unwrapGoogle(rawHref)
            if (title.isBlank() || !link.startsWith("http") ||
                link.contains("google.com/search") || link.contains("google.com/url")) continue
            val after = html.substring(anchors.end(), (anchors.end() + 1500).coerceAtMost(html.length))
            val snippet = Regex("""(?is)<(?:div|span)[^>]*>([^<>]{40,500})</(?:div|span)>""")
                .find(after)?.groupValues?.get(1)?.let { htmlToText(it).take(420) }.orEmpty()
            if (out.none { it.second == link }) out += Triple(title, link, snippet)
        }
        return out
    }

    private fun unwrapGoogle(href: String): String {
        if (href.startsWith("/url?")) {
            val target = Regex("""[?&](?:q|url)=([^&]+)""").find(href)?.groupValues?.get(1)
            if (target != null) return try { java.net.URLDecoder.decode(target, "UTF-8") } catch (_: Exception) { href }
        }
        return href
    }

    private fun parseResults(html: String): List<Triple<String, String, String>> {
        val out = mutableListOf<Triple<String, String, String>>()
        val anchor = Pattern.compile(
            """(?is)<a[^>]*class=["'][^"']*result__a[^"']*["'][^>]*href=["']([^"']+)["'][^>]*>(.*?)</a>"""
        ).matcher(html)
        while (anchor.find() && out.size < 8) {
            val href = decodeEntities(anchor.group(1))
            val title = htmlToText(anchor.group(2)).take(180)
            val link = unwrapDuckDuckGo(href)
            if (title.isBlank() || !link.startsWith("http")) continue
            val after = html.substring(anchor.end(), (anchor.end() + 1800).coerceAtMost(html.length))
            val snippetMatch = Regex("""(?is)<(?:a|div)[^>]*class=["'][^"']*result__snippet[^"']*["'][^>]*>(.*?)</(?:a|div)>""").find(after)
            val snippet = snippetMatch?.groupValues?.get(1)?.let { htmlToText(it).take(420) }.orEmpty()
            if (out.none { it.second == link }) out += Triple(title, link, snippet)
        }
        return out
    }

    private fun unwrapDuckDuckGo(href: String): String {
        val absolute = if (href.startsWith("//")) "https:$href" else href
        val target = Regex("""[?&]uddg=([^&]+)""").find(absolute)?.groupValues?.get(1)
        return if (target != null) try { java.net.URLDecoder.decode(target, "UTF-8") } catch (_: Exception) { absolute } else absolute
    }

    private fun extractPageText(html: String): String {
        val withoutNoise = html.replace(Regex("""(?is)<(script|style|noscript|svg|nav|footer|header)[^>]*>.*?</\1>"""), " ")
        return htmlToText(withoutNoise).replace(Regex("\\s+"), " ").trim()
    }

    @Suppress("DEPRECATION")
    private fun htmlToText(value: String): String {
        val decoded = decodeEntities(value)
        val result = if (Build.VERSION.SDK_INT >= 24) Html.fromHtml(decoded, Html.FROM_HTML_MODE_LEGACY) else Html.fromHtml(decoded)
        return result.toString().replace(Regex("\\s+"), " ").trim()
    }

    private fun decodeEntities(value: String): String =
        value.replace("&amp;", "&").replace("&quot;", "\"")
            .replace("&#x27;", "'").replace("&#39;", "'")
            .replace("&lt;", "<").replace("&gt;", ">")
}

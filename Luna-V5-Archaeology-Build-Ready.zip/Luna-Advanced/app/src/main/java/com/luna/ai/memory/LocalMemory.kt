package com.luna.ai.memory

import android.content.Context

/** Minimal local memory. Recording is off until the user explicitly enables it. */
class LocalMemory(context: Context) {
    private val prefs = context.getSharedPreferences("luna_memory", Context.MODE_PRIVATE)

    fun isEnabled(): Boolean = prefs.getBoolean("memory_enabled", false)

    fun setEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("memory_enabled", enabled).apply()
        if (!enabled) prefs.edit().remove("last_command").apply()
    }

    fun rememberCommand(command: String) {
        if (isEnabled()) {
            prefs.edit().putString("last_command", command).apply()
        }
    }

    fun lastCommand(): String? = if (isEnabled()) prefs.getString("last_command", null) else null
}

package com.luna.ai.avatar

class AvatarController {
    var state: String = "stand"
        private set

    fun rotate() { state = "rotate" }
    fun sit() { state = "sit" }
    fun stand() { state = "stand" }
}

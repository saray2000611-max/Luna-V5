package com.luna.ai.archaeology

import java.util.Locale
import kotlin.math.ln
import kotlin.math.roundToLong

/** Offline helpers for archaeology: text normalisation, radiocarbon arithmetic and recording checklists. */
object ArchaeologyTools {

    /** Unifies Persian/Arabic letter variants and digits so voice and typed input match the same way. */
    fun normalize(value: String): String {
        val sb = StringBuilder(value.length)
        for (ch in value) {
            sb.append(
                when (ch) {
                    '\u200c', '\u200f', '\u200e' -> ' '
                    '\u064A' -> '\u06CC'
                    '\u0643' -> '\u06A9'
                    in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                    in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                    else -> ch
                }
            )
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim().lowercase(Locale.ROOT)
    }

    /**
     * Conventional (uncalibrated) radiocarbon age from the percentage of C-14 remaining,
     * using the Libby mean-life of 8033 years: t = -8033 * ln(F).
     * Returns null when the text is not a radiocarbon-calculation request.
     */
    fun radiocarbonFromRemaining(text: String): String? {
        val t = normalize(text).replace(Regex("(?:رادیو)?کربن\\s*-?\\s*14|c-?14"), "کربن")
        if (!t.contains("کربن") || !t.contains("باقی")) return null
        val match = Regex("(\\d+(?:[.,\u066B]\\d+)?)\\s*(?:درصد|%)").find(t) ?: return null
        val pct = match.groupValues[1].replace(',', '.').replace('\u066B', '.').toDoubleOrNull() ?: return null
        if (pct <= 0.0 || pct > 100.0) return "درصد کربن ۱۴ باقی‌مانده باید بیشتر از صفر و حداکثر ۱۰۰ باشد."
        val age = -8033.0 * ln(pct / 100.0)
        val rounded = (age / 10.0).roundToLong() * 10L
        val sb = StringBuilder()
        sb.append("🧮 محاسبهٔ رادیوکربن (آفلاین)\n")
        sb.append("کربن ۱۴ باقی‌مانده: $pct درصد\n")
        sb.append("سن رادیوکربنی متعارف ≈ $rounded سال BP (پیش از ۱۹۵۰ میلادی)\n\n")
        sb.append("⚠️ این عدد کالیبره‌نشده است و جایگزین گزارش آزمایشگاه نیست. برای تبدیل به سال تقویمی باید منحنی کالیبراسیون (مثل IntCal) و خطای اندازه‌گیری آزمایشگاه اعمال شود. اثر مخزن، آلودگی و نوع نمونه هم نتیجه را تغییر می‌دهند.")
        if (age > 50000.0) {
            sb.append("\n\nاین سن نزدیک یا فراتر از حد عملی روش رادیوکربن (حدود ۵۰ هزار سال) است و قابل اتکا نیست.")
        }
        return sb.toString()
    }

    fun checklist(query: String): String {
        val q = normalize(query)
        return when {
            q.contains("سفال") -> POTTERY
            q.contains("لایه") || q.contains("بافت") || q.contains("کانتکست") -> CONTEXT
            q.contains("روزانه") || q.contains("کاوش") || q.contains("ترانشه") -> EXCAVATION_LOG
            q.contains("بررسی") || q.contains("پیمایش") || q.contains("محوطه") -> SURVEY
            q.contains("عکس") -> PHOTO
            q.contains("یافته") || q.contains("نگهداری") || q.contains("بسته") -> HANDLING
            else -> MENU
        }
    }

    private const val MENU = "📋 چک‌لیست‌های باستان‌شناسی لونا\n\n" +
        "بگو:\n" +
        "• «چک‌لیست سفال»\n" +
        "• «چک‌لیست لایه و بافت»\n" +
        "• «چک‌لیست کاوش» (گزارش روزانه)\n" +
        "• «چک‌لیست بررسی محوطه»\n" +
        "• «چک‌لیست عکاسی»\n" +
        "• «چک‌لیست نگهداری یافته»\n\n" +
        "برای ذخیرهٔ یک یافته در دفترچهٔ گوشی بگو «ثبت یافته: ...» و برای دیدن فهرست «فهرست یافته‌ها»."

    private const val POTTERY = "🏺 برگهٔ ثبت سفال\n\n" +
        "1. شناسهٔ یافته و تاریخ ثبت\n" +
        "2. محوطه، ترانشه و شمارهٔ بافت (لایه)\n" +
        "3. عمق یا ارتفاع نسبی و مختصات محلی\n" +
        "4. نوع قطعه: لبه، بدنه، کف، دسته، کامل\n" +
        "5. خمیره: رنگ، دانه‌بندی، مواد افزودنی\n" +
        "6. پخت: یکنواخت یا ناقص، رنگ مغز\n" +
        "7. پوشش، لعاب یا نقش\n" +
        "8. شیوهٔ ساخت: دست، چرخ، قالب\n" +
        "9. ابعاد و وزن\n" +
        "10. عکس با خط‌کش مقیاس و جهت شمال\n" +
        "11. وضعیت حفاظتی و ثبت‌کننده\n\n" +
        "قدمت را فقط از بافت و مقایسهٔ کارشناسی نتیجه بگیر، نه از ظاهر یک قطعه."

    private const val CONTEXT = "🧱 برگهٔ ثبت بافت (لایه)\n\n" +
        "1. شمارهٔ یکتای بافت\n" +
        "2. نوع: لایه، گودال، پرشدگی، دیوار، کف، کوره…\n" +
        "3. توصیف خاک: رنگ، بافت، فشردگی، مواد همراه\n" +
        "4. روابط لایه‌ای: روی، زیر، بریده‌شده توسط، پرکنندهٔ، چسبیده به\n" +
        "5. ابعاد، شکل و ارتفاع بالا و پایین\n" +
        "6. یافته‌ها و نمونه‌های همراه (مثل نمونهٔ کربن)\n" +
        "7. شمارهٔ عکس‌ها و نقشه‌ها\n" +
        "8. تفسیر اولیه و ثبت‌کننده\n\n" +
        "روابط بین بافت‌ها پایهٔ رسم ماتریس هریس هستند."

    private const val EXCAVATION_LOG = "⛏️ گزارش روزانهٔ کاوش\n\n" +
        "1. تاریخ، آب‌وهوا و اعضای تیم\n" +
        "2. ترانشه و هدف کار امروز\n" +
        "3. بافت‌های بازشده و بسته‌شده\n" +
        "4. یافته‌ها و نمونه‌های برداشته‌شده\n" +
        "5. عکس‌ها، طرح‌ها و ترازیابی\n" +
        "6. مشکلات، ایمنی و آسیب‌های احتمالی\n" +
        "7. برنامهٔ روز بعد\n\n" +
        "کاوش فقط با مجوز رسمی و زیر نظر باستان‌شناس مسئول انجام می‌شود."

    private const val SURVEY = "🗺️ فرم بررسی محوطه\n\n" +
        "1. نام یا شناسهٔ محل و مختصات GPS\n" +
        "2. شرایط سطح: شخم‌خورده، چمن، خاک بکر\n" +
        "3. پوشش گیاهی و دید سطح زمین\n" +
        "4. تراکم و نوع مواد سطحی\n" +
        "5. محدودهٔ پراکنش و پستی‌بلندی\n" +
        "6. تهدیدها: کشاورزی، ساخت‌وساز، حفاری غیرمجاز، فرسایش\n" +
        "7. عکس‌ها و نقشهٔ ساده\n\n" +
        "اگر محوطه ثبت یا حفاظت‌نشده است، مختصات دقیق را فقط به مرجع رسمی میراث فرهنگی بده."

    private const val PHOTO = "📷 راهنمای عکاسی مستندنگاری\n\n" +
        "1. خط‌کش مقیاس و پیکان شمال داخل کادر\n" +
        "2. تابلوی شناسه با شمارهٔ بافت یا یافته\n" +
        "3. زمینهٔ خنثی و نور یکنواخت بدون سایهٔ تند\n" +
        "4. چند زاویه: روبه‌رو، بالا، پهلو، و یک نمای کلی\n" +
        "5. عکس قبل و بعد از هر برداشت\n" +
        "6. فایل‌های اصلی را حذف یا ویرایش نکن\n" +
        "7. شمارهٔ هر عکس را در دفترچه ثبت کن"

    private const val HANDLING = "🧤 چک‌لیست نگهداری یافته\n\n" +
        "1. شیء را تمیز یا شست‌وشو نکن و خاک چسبیده را نکن\n" +
        "2. پیش از جابه‌جایی از بافت و موقعیتش عکس بگیر\n" +
        "3. درون کیسه یا جعبهٔ جداگانه با برچسب بافت و شناسه بگذار\n" +
        "4. مواد مختلف (سفال، فلز، استخوان) را جدا نگه دار\n" +
        "5. اشیای شکننده را با پشتیبان نرم نگه دار و روی هم نچین\n" +
        "6. از نور مستقیم، گرما و رطوبت دور نگه دار\n" +
        "7. روی خود شیء چسب نچسبان و چیزی ننویس\n" +
        "8. اگر خارج از کاوش رسمی پیدا شده، به میراث فرهنگی گزارش بده"
}

package com.luna.ai.voice

class VoiceEngine {
    val inputLanguage = "fa-IR"
    val outputLanguage = "fa-IR"
}

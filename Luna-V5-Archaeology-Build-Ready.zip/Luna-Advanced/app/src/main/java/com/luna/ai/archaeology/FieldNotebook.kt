package com.luna.ai.archaeology

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Private on-device find register. Stores short text notes only, with no location or photos.
 * Data stays in the app's own SharedPreferences.
 */
class FieldNotebook(context: Context) {
    private val prefs = context.getSharedPreferences("luna_archaeology_notebook", Context.MODE_PRIVATE)

    fun count(): Int = load().length()

    fun add(description: String): String {
        val text = description.trim().take(MAX_TEXT)
        if (text.isEmpty()) {
            return "شرح یافته را هم بگو؛ مثلاً «ثبت یافته: قطعه لبهٔ سفال، ترانشه ۲، بافت ۱۰۵»."
        }
        val arr = load()
        if (arr.length() >= MAX_ENTRIES) {
            return "دفترچه پر است (حداکثر $MAX_ENTRIES یافته). فهرست را بررسی کن و در صورت نیاز «پاک کردن یافته‌ها» را بگو."
        }
        val next = prefs.getInt("next_id", 1)
        val id = "F-" + String.format(Locale.US, "%03d", next)
        arr.put(JSONObject().put("id", id).put("time", System.currentTimeMillis()).put("text", text))
        prefs.edit().putString("finds", arr.toString()).putInt("next_id", next + 1).apply()
        return "📝 یافته با شناسهٔ $id در دفترچهٔ محلی ثبت شد:\n$text\n\nتعداد یافته‌های ثبت‌شده: ${arr.length()}"
    }

    fun list(): String {
        val arr = load()
        if (arr.length() == 0) {
            return "دفترچهٔ یافته‌ها خالی است. برای ثبت بگو «ثبت یافته: ...»."
        }
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val sb = StringBuilder("📒 دفترچهٔ یافته‌ها (${arr.length()} مورد)\n")
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            sb.append("\n").append(o.optString("id")).append(" | ")
                .append(fmt.format(Date(o.optLong("time")))).append(" | ")
                .append(o.optString("text"))
        }
        sb.append("\n\nاین یادداشت‌ها فقط روی همین گوشی ذخیره می‌شوند. اگر محوطه حفاظت‌نشده است، موقعیت دقیق را فقط به مرجع رسمی میراث فرهنگی بده.")
        return sb.toString()
    }

    fun clear() {
        prefs.edit().remove("finds").remove("next_id").apply()
    }

    private fun load(): JSONArray =
        try {
            JSONArray(prefs.getString("finds", "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }

    companion object {
        private const val MAX_TEXT = 500
        private const val MAX_ENTRIES = 500

        /** Removes the command words and returns only the find description. */
        fun extractDescription(command: String): String {
            var s = command
            listOf("لونا", "ثبت یافته", "یافته ثبت کن", "یافته را ثبت کن", "ثبت کشف", "کشف ثبت کن", "ثبت کن")
                .sortedByDescending { it.length }
                .forEach { s = s.replace(it, " ") }
            return s.replace(Regex("\\s+"), " ").trim().trim(':', '،', ',', '-', '.')
        }
    }
}

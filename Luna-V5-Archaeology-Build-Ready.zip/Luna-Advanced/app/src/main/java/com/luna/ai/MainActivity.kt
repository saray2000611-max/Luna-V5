package com.luna.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import com.luna.ai.core.LunaCore
import com.luna.ai.web.WebResearch
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private lateinit var tts: TextToSpeech
    private lateinit var luna: LunaCore
    private lateinit var assetLoader: WebViewAssetLoader
    private val voiceRequest = 700
    private val pdfRequest = 701
    private var ttsReady = false
    private val researchExecutor = Executors.newSingleThreadExecutor()
    private val webResearch = WebResearch()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        luna = LunaCore(this)
        web = findViewById(R.id.lunaWeb)
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: android.webkit.WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)
        }
        web.addJavascriptInterface(LunaBridge(), "LunaAndroid")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        tts = TextToSpeech(this, this)
        requestAudioIfNeeded()
    }

    private inner class LunaBridge {
        @JavascriptInterface fun startVoice() { runOnUiThread { startVoice() } }
        @JavascriptInterface fun openPdf() { runOnUiThread { openPdfPicker() } }
        @JavascriptInterface fun speak(text: String) { runOnUiThread { speak(text) } }
        @JavascriptInterface fun sendCommand(text: String) { runOnUiThread { processCommand(text) } }
    }

    private fun requestAudioIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), voiceRequest)
        }
    }

    private fun startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestAudioIfNeeded()
            updateStatus("برای فرمان صوتی، اجازهٔ میکروفون لازم است.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "با لونا صحبت کنید")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { startActivityForResult(intent, voiceRequest) }
        catch (_: Exception) { updateStatus("سرویس تشخیص گفتار روی گوشی در دسترس نیست.") }
    }

    private fun openPdfPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
        }
        startActivityForResult(intent, pdfRequest)
    }

    @Deprecated("Deprecated API retained for Android 6 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == pdfRequest) {
            val uri: Uri = data.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            try {
                val reply = luna.importPdf(uri)
                updateStatus(reply)
                speak(reply)
            } catch (e: Exception) {
                val reply = "خطا در خواندن PDF: ${e.message ?: "فایل نامعتبر است"}"
                updateStatus(reply); speak(reply)
            }
            return
        }
        if (requestCode == voiceRequest) {
            val text = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            processCommand(text)
        }
    }

    /** Shared entry point for spoken and typed commands. */
    private fun processCommand(text: String) {
        val command = text.trim().take(1000)
        if (command.isEmpty()) return
        val result = luna.handleCommand(command)
        web.evaluateJavascript("window.lunaCommand(${org.json.JSONObject.quote(command)}, ${org.json.JSONObject.quote(result.action)})", null)
        updateStatus(result.reply)
        when (result.action) {
            "pdf.open" -> openPdfPicker()
            "web.search" -> runWebResearch(result.payload, false)
            "web.archaeology" -> runWebResearch(result.payload, true)
            else -> speak(result.reply.take(1200))
        }
    }

    private fun runWebResearch(query: String, archaeologyMode: Boolean) {
        updateStatus("در حال جست‌وجوی وب و بررسی حداکثر چهار صفحه…")
        researchExecutor.execute {
            val resultText = try {
                webResearch.search(query, archaeologyMode).text
            } catch (e: Exception) {
                "جست‌وجوی وب انجام نشد: ${e.message ?: "اتصال اینترنت یا موتور جست‌وجو در دسترس نیست."}\n" +
                    "اگر اینترنت قطع است، می‌توانی بگویی «آخرین تحقیق» تا نتیجهٔ قبلی ذخیره‌شده را ببینی، یا از دانش آفلاین باستان‌شناسی استفاده کنی."
            }
            luna.saveResearchResult(resultText.take(20000))
            runOnUiThread {
                updateStatus(resultText)
                speak(resultText.take(1200))
            }
        }
    }

    private fun updateStatus(text: String) {
        web.evaluateJavascript("window.setLunaStatus(${org.json.JSONObject.quote(text)})", null)
    }

    private fun speak(text: String) {
        if (!::tts.isInitialized || !ttsReady) return
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "LUNA_RESPONSE")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val fa = tts.setLanguage(Locale("fa", "IR"))
            ttsReady = fa != TextToSpeech.LANG_MISSING_DATA && fa != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) updateStatus("صدای فارسی در موتور گفتار گوشی نصب نیست؛ از تنظیمات Text-to-Speech زبان فارسی را نصب کن.")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        researchExecutor.shutdownNow()
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}

package com.luna.ai.core

import android.content.Context
import android.net.Uri
import com.luna.ai.ai.LocalAiEngine
import com.luna.ai.archaeology.ArchaeologyKnowledge
import com.luna.ai.archaeology.ArchaeologyTools
import com.luna.ai.archaeology.FieldNotebook
import com.luna.ai.avatar.AvatarController
import com.luna.ai.documents.PdfKnowledge
import com.luna.ai.memory.LocalMemory
import java.util.Locale

data class LunaResult(val reply: String, val action: String = "none", val payload: String = "")

class LunaCore(context: Context) {
    private val memory = LocalMemory(context)
    private val pdf = PdfKnowledge(context)
    private val localAi = LocalAiEngine(pdf)
    private val avatar = AvatarController()
    private val archaeology = ArchaeologyKnowledge()
    private val notebook = FieldNotebook(context)
    private val prefs = context.getSharedPreferences("luna_research", Context.MODE_PRIVATE)

    fun handleCommand(command: String): LunaResult {
        val normalized = normalize(command).lowercase(Locale.ROOT)
        val radiocarbon = ArchaeologyTools.radiocarbonFromRemaining(command)
        val result = when {
            containsAny(normalized, "حافظه را فعال کن", "حافظه فعال", "اجازه حافظه") -> {
                memory.setEnabled(true)
                LunaResult("حافظه محلی فعال شد. فقط آخرین فرمان ذخیره می‌شود.")
            }
            containsAny(normalized, "حافظه را خاموش کن", "حافظه غیرفعال", "حافظه را پاک کن") -> {
                memory.setEnabled(false)
                LunaResult("حافظه محلی خاموش شد و آخرین فرمان ذخیره‌شده پاک شد.")
            }
            containsAny(normalized, "آخرین فرمان", "فرمان قبلی") -> {
                LunaResult(if (!memory.isEnabled()) {
                    "حافظه خاموش است. اگر اجازه بدهی بگو «حافظه را فعال کن»."
                } else {
                    "آخرین فرمان ذخیره‌شده: ${memory.lastCommand() ?: "هنوز فرمانی ذخیره نشده است."}"
                })
            }
            containsAny(normalized, "آخرین تحقیق", "تحقیق قبلی", "آخرین پژوهش") -> {
                LunaResult(prefs.getString("last_result", null)
                    ?: "هنوز نتیجهٔ پژوهش آنلاینی ذخیره نشده است. وقتی اینترنت وصل است بگو «دربارهٔ ... تحقیق کن».")
            }
            containsAny(normalized, "ثبت یافته", "یافته ثبت", "ثبت کشف", "کشف ثبت") ->
                LunaResult(notebook.add(FieldNotebook.extractDescription(command)), "archaeology.note")
            containsAny(normalized, "پاک کردن یافته", "یافته ها را پاک", "حذف یافته ها", "پاک کردن دفترچه") -> {
                if (containsAny(normalized, "تایید", "تأیید", "تاييد", "مطمئنم")) {
                    notebook.clear()
                    LunaResult("دفترچهٔ یافته‌ها پاک شد.", "archaeology.note")
                } else {
                    LunaResult("این کار همهٔ ${notebook.count()} یافتهٔ ثبت‌شده را برای همیشه پاک می‌کند. اگر مطمئنی بگو «پاک کردن یافته‌ها را تأیید می‌کنم».", "archaeology.note")
                }
            }
            containsAny(normalized, "فهرست یافته", "لیست یافته", "یافته های ثبت", "دفترچه میدانی", "دفتر میدانی", "دفترچه کاوش") ->
                LunaResult(notebook.list(), "archaeology.note")
            radiocarbon != null -> LunaResult(radiocarbon, "archaeology.calc")
            containsAny(normalized, "چک لیست", "چکلیست", "برگه ثبت", "برگه کاوش", "فرم ثبت", "فرم بررسی", "راهنمای ثبت", "راهنمای عکاسی") ->
                LunaResult(ArchaeologyTools.checklist(command), "archaeology.checklist")
            isWebResearchRequest(normalized) -> {
                val query = cleanResearchQuery(command)
                if (query.isBlank()) {
                    LunaResult("موضوع جست‌وجو را هم بگو؛ مثلاً «دربارهٔ تخت جمشید تحقیق کن».")
                } else {
                    val archaeologyMode = containsAny(normalized, "باستان شناسی", "باستان‌شناسی", "اثر باستانی",
                        "محوطه تاریخی", "محوطهٔ تاریخی", "کاوش باستانی", "تخت جمشید", "پاسارگاد", "سفال باستانی",
                        "کتیبه", "تمدن باستان") || archaeology.matches(command)
                    LunaResult("در حال جست‌وجوی وب و بررسی صفحات…", if (archaeologyMode) "web.archaeology" else "web.search", query)
                }
            }
            archaeology.matches(command) -> {
                val offline = archaeology.answer(command)
                LunaResult(offline ?: "برای پژوهش زنده دربارهٔ این موضوع، وقتی اینترنت وصل است بگو «دربارهٔ این موضوع تحقیق کن».", "archaeology.answer")
            }
            containsAny(normalized, "بچرخ", "چرخ", "دور بزن") -> {
                avatar.rotate()
                LunaResult("حتماً، لونا می‌چرخد.", "avatar.rotate")
            }
            containsAny(normalized, "بشین", "بنشین", "بشین زمین") -> {
                avatar.sit()
                LunaResult("حتماً، می‌نشینم.", "avatar.sit")
            }
            containsAny(normalized, "پاشو", "بلند شو", "بایست") -> {
                avatar.stand()
                LunaResult("حتماً، می‌ایستم.", "avatar.stand")
            }
            containsAny(normalized, "باز کردن pdf", "بازکردن pdf", "باز کردن پی دی اف",
                "بازکردن پی دی اف", "انتخاب pdf", "انتخاب فایل") ->
                LunaResult("فایل PDF را انتخاب کن.", "pdf.open")
            else -> LunaResult(localAi.answer(command), "assistant.answer")
        }
        if (memory.isEnabled() && !normalized.contains("حافظه را خاموش کن") &&
            !normalized.contains("حافظه غیرفعال") && !normalized.contains("حافظه را پاک کن")) {
            memory.rememberCommand(command)
        }
        return result
    }

    fun importPdf(uri: Uri): String = pdf.importPdf(uri)

    fun saveResearchResult(result: String) {
        prefs.edit().putString("last_result", result).apply()
    }

    private fun isWebResearchRequest(text: String): Boolean {
        val explicitIntent = containsAny(text, "جستجو کن", "جست‌وجو کن", "در اینترنت", "توی اینترنت",
            "در گوگل", "تو گوگل", "در وب", "توی وب", "تحقیق کن", "پژوهش کن",
            "منابع پیدا کن", "صفحات وب", "سرچ کن", "بررسی منابع")
        return explicitIntent
    }

    private fun cleanResearchQuery(command: String): String {
        var q = normalize(command)
        val phrases = listOf(
            "لونا", "لطفاً", "لطفا", "میشه", "میشه لطفا", "برام", "برای من",
            "در اینترنت جستجو کن", "در اینترنت جست‌وجو کن", "توی اینترنت جستجو کن",
            "در گوگل جستجو کن", "تو گوگل سرچ کن", "در وب جستجو کن", "توی وب جستجو کن",
            "جستجو کن", "جست‌وجو کن", "سرچ کن", "تحقیق کن", "پژوهش کن",
            "منابع پیدا کن", "صفحات وب را بررسی کن", "در اینترنت", "توی اینترنت", "در گوگل", "تو گوگل", "در وب", "توی وب"
        )
        phrases.map { normalize(it) }.distinct().sortedByDescending { it.length }.forEach { phrase ->
            q = q.replace(Regex("(?i)" + Regex.escape(phrase)), " ")
        }
        return q.replace(Regex("\\s+"), " ").trim().trim('؟', '?', '.', '،', ',')
    }

    private fun containsAny(text: String, vararg phrases: String): Boolean =
        phrases.any { text.contains(normalize(it).lowercase(Locale.ROOT)) }

    private fun normalize(value: String): String =
        value.replace('\u200c', ' ')
            .replace('\u200f', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
}

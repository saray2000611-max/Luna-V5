package com.luna.ai.ai

class ModelRouter {
    fun route(command: String): String {
        val c = command.lowercase()
        return when {
            c.contains("تحقیق کن") || c.contains("جستجو کن") || c.contains("جست‌وجو کن") ||
                c.contains("در اینترنت") || c.contains("در گوگل") -> "web-research"
            c.contains("باستان") || c.contains("تخت جمشید") || c.contains("پاسارگاد") -> "archaeology-knowledge"
            c.contains("کد") || c.contains("برنامه") -> "coding-model"
            c.contains("عکس") || c.contains("تصویر") || c.contains("دوربین") -> "vision-model"
            c.contains("ترجمه") || c.contains("زبان") -> "language-model"
            c.contains("pdf") || c.contains("فایل") -> "document-engine"
            else -> "general-reasoning-model"
        }
    }
}

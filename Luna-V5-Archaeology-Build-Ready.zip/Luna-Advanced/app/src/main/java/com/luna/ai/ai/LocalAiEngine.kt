package com.luna.ai.ai

import com.luna.ai.documents.PdfKnowledge
import java.util.Locale

/**
 * Lightweight offline intent handling and retrieval, not a generative LLM.
 * A real on-device language model and inference runtime must be installed
 * separately before free-form generative answers can be enabled.
 */
class LocalAiEngine(private val pdf: PdfKnowledge) {
    fun answer(input: String): String {
        val q = normalize(input).trim()
        if (q.isEmpty()) return "صدایت را واضح‌تر بگو."
        val lower = q.lowercase(Locale.ROOT)

        if (containsAny(lower, "وضعیت pdf", "دانش pdf", "چه فایلی", "فایل وارد شده")) {
            return if (pdf.hasDocument()) {
                "فایل «${pdf.documentTitle()}» در حافظه محلی موجود است و جست‌وجوی متن آن بدون اینترنت انجام می‌شود."
            } else {
                "هنوز فایلی وارد نشده است. بگو «باز کردن PDF»."
            }
        }

        if (containsAny(lower, "طبق pdf", "طبق فایل", "در فایل", "داخل pdf", "داخل پی دی اف",
                "جستجو", "جست و جو", "جست‌وجو", "پیدا کن در pdf")) {
            val query = q.replace(
                Regex("(?i)طبق\\s*(pdf|فایل)|در\\s*فایل|داخل\\s*(pdf|پی\\s*دی\\s*اف)|پیدا\\s*کن\\s*در\\s*pdf|جست[وجوآ]+"),
                " "
            ).trim()
            return pdf.search(query.ifBlank { q })
        }

        return when {
            containsAny(lower, "سلام", "درود") ->
                "سلام، من لونا هستم. فرمان‌های آواتار و جست‌وجوی آفلاین PDF آماده‌اند."
            containsAny(lower, "کمک", "چه کار", "قابلیت") ->
                "در این نسخه می‌توانم فرمان‌های آواتار را اجرا کنم، PDF متنی را وارد و در آن جست‌وجو کنم، و در باستان‌شناسی راهنمای آفلاین، چک‌لیست‌های ثبت، دفترچهٔ یافته و محاسبهٔ رادیوکربن ارائه دهم (بگو «باستان‌شناسی»). پاسخ‌گویی آزاد با مدل زبانی محلی هنوز فعال نیست."
            containsAny(lower, "اینترنت", "آنلاین", "جستجوی وب", "جست‌وجوی وب") ->
                "جست‌وجوی وب اولیه اضافه شده است. برای اجرای آن بگو «دربارهٔ [موضوع] تحقیق کن». این قابلیت به اینترنت نیاز دارد و اگر موتور جست‌وجو ساختار صفحه را تغییر دهد ممکن است نتایج استخراج نشوند."
            else ->
                "من در حالت آفلاین هستم. می‌توانم در PDF واردشده جست‌وجو کنم و فرمان‌های مشخص را اجرا کنم. برای پاسخ‌گویی عمومی و استدلال آزاد، باید مدل زبانی محلی و موتور استنتاج به برنامه اضافه شوند."
        }
    }

    private fun containsAny(text: String, vararg phrases: String): Boolean =
        phrases.any { text.contains(normalize(it).lowercase(Locale.ROOT)) }

    private fun normalize(value: String): String =
        value.replace('\u200c', ' ')
            .replace('\u200f', ' ')
            .replace(Regex("\\s+"), " ")
}

package com.luna.ai.tools

class ToolRegistry {
    val tools = listOf(
        "internet", "files", "pdf", "vision", "android",
        "coding", "image", "education", "electronics"
    )
}

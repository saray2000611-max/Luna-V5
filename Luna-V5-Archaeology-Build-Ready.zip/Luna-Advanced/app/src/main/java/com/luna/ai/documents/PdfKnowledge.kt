package com.luna.ai.documents

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.util.Locale

/**
 * On-device PDF text extraction and keyword retrieval.
 * No network access is performed here. Image-only/scanned PDFs need OCR, which
 * is not included in this source package.
 */
class PdfKnowledge(private val context: Context) {
    private val textFile = File(context.filesDir, "pdf_knowledge.txt")
    private val titleFile = File(context.filesDir, "pdf_knowledge_title.txt")

    init {
        PDFBoxResourceLoader.init(context.applicationContext)
    }

    @Synchronized
    fun importPdf(uri: Uri): String {
        val displayName = queryDisplayName(uri)
        val extracted = context.contentResolver.openInputStream(uri)?.use { input ->
            PDDocument.load(input).use { document ->
                if (document.numberOfPages <= 0) {
                    throw IllegalStateException("این PDF صفحه‌ای ندارد.")
                }
                PDFTextStripper().apply { sortByPosition = true }.getText(document)
            }
        } ?: throw IllegalStateException("فایل PDF قابل خواندن نیست.")

        val normalizedText = normalize(extracted).trim()
        if (normalizedText.isBlank()) {
            throw IllegalStateException(
                "از این PDF متن قابل استخراج پیدا نشد؛ ممکن است فایل اسکن‌شده یا تصویری باشد."
            )
        }

        // Save to a temporary file first so an interrupted write does not
        // destroy the last successfully imported document.
        val temp = File(context.filesDir, "pdf_knowledge.txt.tmp")
        temp.writeText(normalizedText, Charsets.UTF_8)
        if (!temp.renameTo(textFile)) {
            temp.copyTo(textFile, overwrite = true)
            temp.delete()
        }
        titleFile.writeText(displayName, Charsets.UTF_8)
        return "دانش PDF ذخیره شد: $displayName؛ ${normalizedText.length} نویسه به حافظه محلی اضافه شد."
    }

    fun hasDocument(): Boolean = textFile.exists() && textFile.length() > 0

    fun documentTitle(): String =
        if (titleFile.exists()) titleFile.readText(Charsets.UTF_8).ifBlank { "PDF" } else "PDF"

    @Synchronized
    fun search(query: String, limit: Int = 4): String {
        if (!hasDocument()) {
            return "هنوز PDF وارد نشده است. بگو «باز کردن PDF» تا یک فایل انتخاب کنی."
        }

        val terms = normalize(query).lowercase(Locale.ROOT)
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length >= 2 }
            .distinct()

        if (terms.isEmpty()) return "برای جست‌وجو، چند کلمه کلیدی بگو."

        val paragraphs = textFile.readText(Charsets.UTF_8)
            .split(Regex("\\n\\s*\\n|(?<=[.!?؟؛])\\s+"))
            .map { normalize(it).trim() }
            .filter { it.length > 15 }

        val ranked = paragraphs.map { paragraph ->
            val lower = paragraph.lowercase(Locale.ROOT)
            val hits = terms.count { lower.contains(it) }
            paragraph to hits
        }.filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenByDescending { it.first.length })
            .take(limit.coerceIn(1, 10))

        if (ranked.isEmpty()) {
            return "در PDF «${documentTitle()}» نتیجه‌ای برای این عبارت پیدا نکردم."
        }

        return "از PDF «${documentTitle()}» این بخش‌ها پیدا شد:\n\n" +
            ranked.joinToString("\n\n") { "• ${it.first.take(650)}" }
    }

    private fun queryDisplayName(uri: Uri): String {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (index >= 0) cursor.getString(index) else null
                    } else null
                }?.takeIf { it.isNotBlank() } ?: (uri.lastPathSegment ?: "document.pdf")
        } catch (_: Exception) {
            uri.lastPathSegment ?: "document.pdf"
        }
    }

    private fun normalize(value: String): String =
        value.replace('\u200c', ' ')
            .replace('\u200f', ' ')
            .replace('\u202a', ' ')
            .replace('\u202c', ' ')
            .replace(Regex("[\\t\\x0B\\f\\r ]+"), " ")
}

ساخت آنلاین APK لونا با GitHub Actions
=====================================

این پروژه برای ساخت آنلاین آماده شده است. workflow در مسیر زیر قرار دارد:
.github/workflows/android-apk.yml

روش پیشنهادی:
1) یک مخزن جدید در GitHub بسازید.
2) فایل‌های داخل پوشه Luna-Advanced را در ریشه مخزن بارگذاری کنید (خود پوشه را به‌عنوان زیرپوشه نگذارید؛ فایل settings.gradle باید در ریشه مخزن باشد).
3) از بخش Actions، workflow با نام Build Luna Android APK را اجرا کنید. اگر workflow به‌صورت خودکار دیده نشد، ابتدا یک commit به شاخه main بفرستید.
4) وارد اجرای موفق workflow شوید و از بخش Artifacts، فایل Luna-V4-debug-apk را دانلود کنید.
5) فایل ZIP artifact را باز کنید تا app-debug.apk را ببینید.

نکات امنیتی:
- رمز عبور GitHub یا Personal Access Token را در چت با هیچ‌کس به اشتراک نگذارید.
- برای این workflow نیازی به GitHub token سفارشی داخل فایل‌های پروژه نیست؛ خود GitHub Actions آن را اجرا می‌کند.
- APK این workflow نسخه debug است و امضای انتشار نهایی ندارد.

اگر ساخت شکست خورد، متن خطای انتهای گزارش Actions را نگه دارید تا بر اساس همان خطا اصلاح کنیم.

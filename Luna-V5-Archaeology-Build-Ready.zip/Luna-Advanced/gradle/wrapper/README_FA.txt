فایل gradle-wrapper.jar عمداً در این بسته وجود ندارد؛ بنابراین دستور ./gradlew فعلاً اجراشدنی نیست.
پروژه با Android Gradle Plugin 8.13.0 تنظیم شده و Gradle 8.13 توصیه می‌شود.

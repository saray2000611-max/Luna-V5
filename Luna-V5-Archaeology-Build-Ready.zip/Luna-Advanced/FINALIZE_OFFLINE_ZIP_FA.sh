#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PARENT="$(dirname "$ROOT")"
cd "$ROOT"

echo "[1/4] بررسی کتابخانه سه‌بعدی محلی..."
bash "$ROOT/DOWNLOAD_OFFLINE_VIEWER_FA.sh"
test -s "$ROOT/app/src/main/assets/model-viewer.min.js"

echo "[2/4] بررسی ساختار پروژه..."
python3 "$ROOT/tools/verify_package.py"

echo "[3/4] آماده‌سازی ابزار ZIP..."
if ! command -v zip >/dev/null 2>&1; then
  echo "ابزار zip نصب نیست. اجرا کن: pkg install zip python -y"
  exit 2
fi
mkdir -p "$HOME/storage/downloads"
OUT="$HOME/storage/downloads/Luna-Advanced-Offline-Complete.zip"
rm -f "$OUT"
cd "$PARENT"
zip -qr "$OUT" "$(basename "$ROOT")"
unzip -t "$OUT" | tail -n 2

echo "[4/4] بسته آماده شد:"
ls -lh "$OUT"
echo "توجه: این فقط صحت ZIP را بررسی می‌کند؛ ساخت APK و آزمایش در حالت پرواز جداگانه لازم است."

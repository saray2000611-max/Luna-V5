#!/usr/bin/env python3
"""Static sanity checks for the Luna source tree; does not replace Android build/device tests."""
from pathlib import Path
import struct, sys

root = Path(__file__).resolve().parents[1]
errors = []
warnings = []

required = [
    "settings.gradle",
    "build.gradle",
    "app/build.gradle",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/luna/ai/MainActivity.kt",
    "app/src/main/java/com/luna/ai/core/LunaCore.kt",
    "app/src/main/java/com/luna/ai/ai/LocalAiEngine.kt",
    "app/src/main/java/com/luna/ai/documents/PdfKnowledge.kt",
    "app/src/main/assets/index.html",
    "app/src/main/java/com/luna/ai/archaeology/ArchaeologyKnowledge.kt",
    "app/src/main/java/com/luna/ai/archaeology/ArchaeologyTools.kt",
    "app/src/main/java/com/luna/ai/archaeology/FieldNotebook.kt",
    "app/src/main/assets/Luna_3D_Voice.glb",
]
for rel in required:
    if not (root / rel).is_file():
        errors.append(f"Missing required file: {rel}")

glb = root / "app/src/main/assets/Luna_3D_Voice.glb"
if glb.is_file():
    data = glb.read_bytes()
    if len(data) < 20 or data[:4] != b"glTF":
        errors.append("GLB header invalid")
    else:
        version, declared = struct.unpack_from("<II", data, 4)
        if version != 2 or declared != len(data):
            errors.append(f"GLB size/version mismatch: version={version}, declared={declared}, actual={len(data)}")

html = root / "app/src/main/assets/index.html"
if html.is_file():
    content = html.read_text(encoding="utf-8")
    if 'src="luna-model-viewer.min.js"' not in content:
        errors.append("index.html must use the local model-viewer library")
    if "https://" in content or "http://" in content:
        errors.append("index.html contains a remote URL; offline page must not depend on remote URLs")
    for command in ("avatar.rotate", "avatar.sit", "avatar.stand", "LunaAndroid.sendCommand"):
        if command not in content:
            warnings.append(f"Expected action not found in index.html: {command}")

viewer = root / "app/src/main/assets/luna-model-viewer.min.js"
if not viewer.is_file() or viewer.stat().st_size < 10_000:
    errors.append("Local offline WebGL viewer is missing or incomplete")
real_avatar = root / "app/src/main/assets/Luna_Realistic_Avatar.glb"
if not real_avatar.is_file() or real_avatar.stat().st_size < 100_000:
    errors.append("Natural-looking avatar GLB is missing or incomplete")
elif real_avatar.read_bytes()[:4] != b"glTF":
    errors.append("Natural-looking avatar GLB header invalid")
else:
    import struct
    rd = real_avatar.read_bytes()
    version, declared = struct.unpack_from("<II", rd, 4)
    if version != 2 or declared != len(rd):
        errors.append(f"Natural avatar GLB size/version mismatch: version={version}, declared={declared}, actual={len(rd)}")

build = root / "app/build.gradle"
if build.is_file():
    b = build.read_text(encoding="utf-8")
    if "com.tom-roush:pdfbox-android" not in b:
        errors.append("PDFBox Android dependency is missing")
    if "androidx.webkit:webkit" not in b:
        errors.append("WebViewAssetLoader dependency is missing")

if errors:
    print("FAILED")
    for item in errors: print("ERROR:", item)
    for item in warnings: print("WARNING:", item)
    sys.exit(1)

print("STRUCTURAL CHECKS PASSED")
for item in warnings: print("WARNING:", item)
print("Note: this is not a Gradle build or runtime test.")

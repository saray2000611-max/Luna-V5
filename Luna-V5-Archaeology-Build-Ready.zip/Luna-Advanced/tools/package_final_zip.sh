#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PARENT="$(dirname "$ROOT")"
NAME="$(basename "$ROOT")"
# Try to fetch both assets. If network is unavailable, keep source package intact
# and clearly report that external binary assets are still missing.
FETCH_OK=1
bash "$ROOT/tools/fetch_model_viewer.sh" || FETCH_OK=0
bash "$ROOT/tools/fetch_realistic_avatar.sh" || FETCH_OK=0
OUTDIR="$HOME/storage/downloads"
[ -d "$OUTDIR" ] || OUTDIR="$HOME"
OUT="$OUTDIR/Luna-Advanced-Offline-Web-Archaeology-v6.zip"
cd "$PARENT"
rm -f "$OUT"
zip -qr "$OUT" "$NAME" -x "$NAME/.gradle/*" "$NAME/app/build/*"
unzip -t "$OUT" | tail -n 2
echo "Created package: $OUT"
ls -lh "$OUT"
if [ "$FETCH_OK" -eq 0 ]; then
  echo "WARNING: ZIP was created, but one or more external binary assets could not be downloaded. See DOWNLOAD_ASSETS_FA.md."
fi

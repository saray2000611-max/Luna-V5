#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets"
TARGET="$ASSETS/Luna_Realistic_Avatar.glb"
if [ ! -s "$TARGET" ] || [ "$(head -c 4 "$TARGET")" != "glTF" ]; then
  echo "مدل آواتار طبیعی داخل بسته نیست یا فایل GLB معتبر نیست: $TARGET" >&2
  exit 1
fi
echo "مدل سه‌بعدی طبیعی لونا از قبل داخل بسته است: $(wc -c < "$TARGET") بایت"
echo "توجه: این مدل رویه‌ای و انسان‌نماست، نه فوتورئالیستی و نه اسکن واقعی انسان."
